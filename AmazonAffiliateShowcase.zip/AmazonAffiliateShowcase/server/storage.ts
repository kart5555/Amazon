import { 
  products, type Product, type InsertProduct,
  categories, type Category, type InsertCategory,
  subscribers, type Subscriber, type InsertSubscriber
} from "@shared/schema";

export interface IStorage {
  // Product methods
  getAllProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  searchProducts(query: string): Promise<Product[]>;
  
  // Category methods
  getAllCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Subscriber methods
  addSubscriber(subscriber: InsertSubscriber): Promise<Subscriber>;
}

export class MemStorage implements IStorage {
  private products: Map<number, Product>;
  private categories: Map<number, Category>;
  private subscribers: Map<number, Subscriber>;
  private productId: number;
  private categoryId: number;
  private subscriberId: number;

  constructor() {
    this.products = new Map();
    this.categories = new Map();
    this.subscribers = new Map();
    this.productId = 1;
    this.categoryId = 1;
    this.subscriberId = 1;
    
    // Initialize with default categories
    this.initializeCategories();
    // Initialize with some sample products
    this.initializeProducts();
  }

  private initializeCategories() {
    const defaultCategories: InsertCategory[] = [
      { name: "Electronics", slug: "electronics" },
      { name: "Home & Kitchen", slug: "home-kitchen" },
      { name: "Fashion", slug: "fashion" },
      { name: "Books", slug: "books" },
      { name: "Beauty", slug: "beauty" },
      { name: "Toys & Games", slug: "toys-games" }
    ];

    defaultCategories.forEach(category => {
      this.createCategory(category);
    });
  }

  private initializeProducts() {
    const defaultProducts: InsertProduct[] = [
      {
        title: "Premium Noise Cancelling Headphones",
        description: "Immersive sound experience with industry-leading noise cancellation, perfect for work or travel. Up to 30 hours of battery life.",
        price: 249.99,
        imageUrl: "https://images.unsplash.com/photo-1581993192353-323e5321c56c?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80",
        amazonUrl: "https://amazon.com/premium-headphones",
        rating: 4.8,
        reviewCount: 2456,
        categoryId: 1, // Electronics
        featured: true,
        badge: "Top Pick"
      },
      {
        title: "Portable Bluetooth Speaker",
        description: "Waterproof portable speaker with powerful 360° sound. 24-hour playtime and durable design that's perfect for outdoor adventures.",
        price: 89.99,
        imageUrl: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80",
        amazonUrl: "https://amazon.com/portable-speaker",
        rating: 4.7,
        reviewCount: 1845,
        categoryId: 1, // Electronics
        featured: true,
        badge: "Best Value"
      },
      {
        title: "Smart Fitness Tracker",
        description: "Advanced health tracking with heart rate monitoring, sleep analysis, and workout detection. Water-resistant with 7-day battery life.",
        price: 129.99,
        imageUrl: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80",
        amazonUrl: "https://amazon.com/fitness-tracker",
        rating: 4.5,
        reviewCount: 3210,
        categoryId: 1, // Electronics
        featured: true,
        badge: "Staff Pick"
      },
      {
        title: "Smart Coffee Maker",
        description: "WiFi-enabled coffee maker you can control from your phone. Program schedules and customize brewing strength.",
        price: 149.99,
        imageUrl: "https://images.unsplash.com/photo-1565104781149-ab4a5a6c397e?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80",
        amazonUrl: "https://amazon.com/smart-coffee-maker",
        rating: 4.2,
        reviewCount: 426,
        categoryId: 2, // Home & Kitchen
        featured: false,
        badge: ""
      },
      {
        title: "Wireless Charging Pad",
        description: "Fast-charging wireless pad compatible with all Qi-enabled devices. Sleek design with LED indicator.",
        price: 29.99,
        imageUrl: "https://images.unsplash.com/photo-1585298723682-7115561c51b7?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80",
        amazonUrl: "https://amazon.com/wireless-charging",
        rating: 4.8,
        reviewCount: 1102,
        categoryId: 1, // Electronics
        featured: false,
        badge: ""
      },
      {
        title: "Indoor Garden Kit",
        description: "Grow fresh herbs year-round with this self-watering indoor garden. Includes LED grow lights and plant pods.",
        price: 99.95,
        imageUrl: "https://images.unsplash.com/photo-1550009158-9ebf69173e03?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80",
        amazonUrl: "https://amazon.com/indoor-garden",
        rating: 4.2,
        reviewCount: 837,
        categoryId: 2, // Home & Kitchen
        featured: false,
        badge: ""
      },
      {
        title: "Smart Door Lock",
        description: "Keyless entry with fingerprint, code, or smartphone app. Easy installation and compatible with smart home systems.",
        price: 199.99,
        imageUrl: "https://images.unsplash.com/photo-1571782742478-0816a4773a10?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80",
        amazonUrl: "https://amazon.com/smart-lock",
        rating: 4.3,
        reviewCount: 612,
        categoryId: 2, // Home & Kitchen
        featured: false,
        badge: ""
      },
      {
        title: "Robot Vacuum Cleaner",
        description: "Smart mapping technology with powerful suction. Self-emptying dustbin and voice control capabilities.",
        price: 349.99,
        imageUrl: "https://images.unsplash.com/photo-1606813907291-d86efa9b94db?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80",
        amazonUrl: "https://amazon.com/robot-vacuum",
        rating: 4.9,
        reviewCount: 2541,
        categoryId: 2, // Home & Kitchen
        featured: false,
        badge: ""
      },
      {
        title: "Reusable Food Storage Bags",
        description: "Eco-friendly silicone food storage bags. Dishwasher safe and leak-proof design. Set of 10 in various sizes.",
        price: 24.95,
        imageUrl: "https://images.unsplash.com/photo-1605236453806-6ff36851218e?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80",
        amazonUrl: "https://amazon.com/storage-bags",
        rating: 4.4,
        reviewCount: 958,
        categoryId: 2, // Home & Kitchen
        featured: false,
        badge: ""
      },
      {
        title: "Bamboo Bath Towel Set",
        description: "Luxurious bamboo fiber towels with superior absorbency. Includes 2 bath towels, 2 hand towels, and 4 washcloths.",
        price: 59.99,
        imageUrl: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80",
        amazonUrl: "https://amazon.com/bamboo-towels",
        rating: 4.8,
        reviewCount: 1426,
        categoryId: 2, // Home & Kitchen
        featured: false,
        badge: ""
      },
      {
        title: "Indoor Plant Collection",
        description: "Set of 4 easy-care houseplants with decorative pots. Perfect for beginners and home decoration.",
        price: 49.99,
        imageUrl: "https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80",
        amazonUrl: "https://amazon.com/plant-collection",
        rating: 4.3,
        reviewCount: 743,
        categoryId: 2, // Home & Kitchen
        featured: false,
        badge: ""
      }
    ];

    defaultProducts.forEach(product => {
      this.createProduct(product);
    });
  }

  // Product methods
  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.categoryId === categoryId);
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.featured);
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.productId++;
    const newProduct = { ...product, id };
    this.products.set(id, newProduct);
    return newProduct;
  }

  async searchProducts(query: string): Promise<Product[]> {
    if (!query) return this.getAllProducts();
    
    const lowerQuery = query.toLowerCase();
    return Array.from(this.products.values()).filter(product => 
      product.title.toLowerCase().includes(lowerQuery) || 
      product.description.toLowerCase().includes(lowerQuery)
    );
  }

  // Category methods
  async getAllCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategoryById(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(category => category.slug === slug);
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.categoryId++;
    const newCategory = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }

  // Subscriber methods
  async addSubscriber(subscriber: InsertSubscriber): Promise<Subscriber> {
    const id = this.subscriberId++;
    const subscriptionDate = new Date();
    const newSubscriber = { ...subscriber, id, subscriptionDate };
    this.subscribers.set(id, newSubscriber);
    return newSubscriber;
  }
}

export const storage = new MemStorage();
