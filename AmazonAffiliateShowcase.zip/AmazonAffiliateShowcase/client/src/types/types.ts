import { Product, Category } from "@shared/schema";

export interface SortOption {
  label: string;
  value: string;
}

export interface PriceRange {
  label: string;
  value: string;
  min?: number;
  max?: number;
}

export interface RatingFilter {
  label: string;
  value: string;
  minRating: number;
}

export interface FilterState {
  category: number | null;
  priceRange: string;
  rating: string;
  sortBy: string;
}

export interface SearchState {
  query: string;
}
