import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";

export function useCategories() {
  const { data: categories = [], isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  return { categories, isLoading };
}
