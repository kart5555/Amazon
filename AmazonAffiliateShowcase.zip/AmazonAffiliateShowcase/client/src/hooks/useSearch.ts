import { useState, useCallback } from 'react';
import { queryClient } from '@/lib/queryClient';

export function useSearch() {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = useCallback(() => {
    // Invalidate products query to refetch with the search parameter
    queryClient.invalidateQueries({ queryKey: ['/api/products'] });
  }, []);

  return {
    searchQuery,
    setSearchQuery,
    handleSearch
  };
}
