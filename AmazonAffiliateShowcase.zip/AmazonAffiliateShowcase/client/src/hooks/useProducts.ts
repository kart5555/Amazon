import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { useMemo } from "react";
import { FilterState, PriceRange, RatingFilter } from "@/types/types";

export function useProducts(filters: FilterState, searchQuery: string = "") {
  // Fetch all products
  const { data: allProducts = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  // Fetch featured products
  const { data: featuredProducts = [] } = useQuery<Product[]>({
    queryKey: ["/api/products/featured"],
  });

  // Apply filters to the products
  const filteredProducts = useMemo(() => {
    let result = [...allProducts];

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (product) =>
          product.title.toLowerCase().includes(query) ||
          product.description.toLowerCase().includes(query)
      );
    }

    // Filter by category
    if (filters.category !== null) {
      result = result.filter((product) => product.categoryId === filters.category);
    }

    // Filter by price range
    if (filters.priceRange !== "all") {
      switch (filters.priceRange) {
        case "under-25":
          result = result.filter((product) => product.price < 25);
          break;
        case "25-50":
          result = result.filter((product) => product.price >= 25 && product.price <= 50);
          break;
        case "50-100":
          result = result.filter((product) => product.price > 50 && product.price <= 100);
          break;
        case "100-200":
          result = result.filter((product) => product.price > 100 && product.price <= 200);
          break;
        case "over-200":
          result = result.filter((product) => product.price > 200);
          break;
      }
    }

    // Filter by rating
    if (filters.rating !== "all") {
      switch (filters.rating) {
        case "4-up":
          result = result.filter((product) => product.rating >= 4);
          break;
        case "3-up":
          result = result.filter((product) => product.rating >= 3);
          break;
        case "2-up":
          result = result.filter((product) => product.rating >= 2);
          break;
        case "1-up":
          result = result.filter((product) => product.rating >= 1);
          break;
      }
    }

    // Sort products
    if (filters.sortBy) {
      switch (filters.sortBy) {
        case "price-asc":
          result.sort((a, b) => a.price - b.price);
          break;
        case "price-desc":
          result.sort((a, b) => b.price - a.price);
          break;
        case "rating":
          result.sort((a, b) => b.rating - a.rating);
          break;
        // Other sort options would go here
      }
    }

    return result;
  }, [allProducts, filters, searchQuery]);

  return { 
    products: filteredProducts,
    featuredProducts,
    isLoading 
  };
}
