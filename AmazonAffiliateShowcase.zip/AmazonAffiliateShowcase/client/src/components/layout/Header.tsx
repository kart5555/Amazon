import { useState } from "react";
import { Link } from "wouter";
import { useCategories } from "@/hooks/useCategories";
import { useSearch } from "@/hooks/useSearch";

const Header = () => {
  const { categories } = useCategories();
  const { searchQuery, setSearchQuery, handleSearch } = useSearch();
  const [searchInput, setSearchInput] = useState("");

  const handleSearchInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchInput(e.target.value);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchQuery(searchInput);
    handleSearch();
  };

  return (
    <header className="bg-[#232F3E] text-white shadow-md">
      <div className="container mx-auto px-6 py-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <Link href="/">
              <a className="text-2xl font-bold">
                <span className="text-[#FF9900]">Affiliate</span>Hub
              </a>
            </Link>
            <p className="ml-2 text-sm hidden md:block">Amazon Product Recommendations</p>
          </div>
          
          <div className="w-full md:w-1/2 lg:w-1/3">
            <form onSubmit={handleSearchSubmit} className="relative">
              <input 
                type="text" 
                placeholder="Search for products..." 
                className="w-full py-2 px-4 rounded-full border-2 border-[#FF9900] focus:outline-none focus:ring-2 focus:ring-[#FF9900] text-[#333333]"
                value={searchInput}
                onChange={handleSearchInputChange}
              />
              <button 
                type="submit"
                className="absolute right-0 top-0 h-full px-4 bg-[#FF9900] rounded-r-full text-white font-medium"
              >
                Search
              </button>
            </form>
          </div>
        </div>
        
        <nav className="mt-6">
          <ul className="flex flex-wrap space-x-1 md:space-x-6 justify-center md:justify-start">
            <li>
              <Link href="/">
                <a className="py-2 px-3 text-sm md:text-base hover:bg-[#37475A] rounded-md transition-colors duration-200">
                  Home
                </a>
              </Link>
            </li>
            <li>
              <Link href="/?featured=true">
                <a className="py-2 px-3 text-sm md:text-base hover:bg-[#37475A] rounded-md transition-colors duration-200">
                  Best Sellers
                </a>
              </Link>
            </li>
            {categories.map((category) => (
              <li key={category.id}>
                <Link href={`/?category=${category.id}`}>
                  <a className="py-2 px-3 text-sm md:text-base hover:bg-[#37475A] rounded-md transition-colors duration-200">
                    {category.name}
                  </a>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;
