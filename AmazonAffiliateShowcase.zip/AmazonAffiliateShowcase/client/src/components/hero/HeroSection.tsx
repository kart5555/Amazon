import { Link } from "wouter";

const HeroSection = () => {
  return (
    <section className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white py-12 md:py-20">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Discover Curated Amazon Products</h2>
          <p className="text-lg mb-8">Handpicked recommendations that solve real problems</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="#trending">
              <a className="bg-[#FF9900] hover:bg-opacity-90 text-white font-medium py-3 px-8 rounded-md transition duration-200">
                Trending Products
              </a>
            </Link>
            <Link href="#categories">
              <a className="bg-white hover:bg-gray-100 text-[#232F3E] font-medium py-3 px-8 rounded-md transition duration-200">
                Browse Categories
              </a>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
