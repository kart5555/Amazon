import { useState, useEffect } from "react";
import { useCategories } from "@/hooks/useCategories";
import { FilterState, PriceRange, RatingFilter, SortOption } from "@/types/types";

interface CategoryFiltersProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
}

const CategoryFilters = ({ filters, onFilterChange }: CategoryFiltersProps) => {
  const { categories } = useCategories();
  const [activeCategory, setActiveCategory] = useState<number | null>(null);
  
  const priceRanges: PriceRange[] = [
    { label: "All Prices", value: "all" },
    { label: "Under $25", value: "under-25", max: 25 },
    { label: "$25 to $50", value: "25-50", min: 25, max: 50 },
    { label: "$50 to $100", value: "50-100", min: 50, max: 100 },
    { label: "$100 to $200", value: "100-200", min: 100, max: 200 },
    { label: "$200 & Above", value: "over-200", min: 200 }
  ];
  
  const ratingFilters: RatingFilter[] = [
    { label: "All Ratings", value: "all", minRating: 0 },
    { label: "4 Stars & Up", value: "4-up", minRating: 4 },
    { label: "3 Stars & Up", value: "3-up", minRating: 3 },
    { label: "2 Stars & Up", value: "2-up", minRating: 2 },
    { label: "1 Star & Up", value: "1-up", minRating: 1 }
  ];
  
  const sortOptions: SortOption[] = [
    { label: "Featured", value: "featured" },
    { label: "Price: Low to High", value: "price-asc" },
    { label: "Price: High to Low", value: "price-desc" },
    { label: "Customer Rating", value: "rating" },
    { label: "Newest Arrivals", value: "newest" }
  ];

  useEffect(() => {
    setActiveCategory(filters.category);
  }, [filters.category]);

  const handleCategoryClick = (categoryId: number | null) => {
    setActiveCategory(categoryId);
    onFilterChange({ ...filters, category: categoryId });
  };

  const handlePriceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ ...filters, priceRange: e.target.value });
  };

  const handleRatingChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ ...filters, rating: e.target.value });
  };

  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onFilterChange({ ...filters, sortBy: e.target.value });
  };

  return (
    <section id="categories" className="mb-12">
      <h2 className="text-2xl md:text-3xl font-bold mb-6">Browse by Category</h2>
      
      <div className="flex flex-wrap gap-4 mb-8">
        <button 
          className={`py-2 px-6 rounded-full ${activeCategory === null ? 'bg-[#232F3E] text-white' : 'bg-white border border-gray-300 hover:border-[#FF9900] text-gray-700'} font-medium transition-colors duration-200`}
          onClick={() => handleCategoryClick(null)}
        >
          All Products
        </button>
        
        {categories.map((category) => (
          <button 
            key={category.id}
            className={`py-2 px-6 rounded-full ${activeCategory === category.id ? 'bg-[#232F3E] text-white' : 'bg-white border border-gray-300 hover:border-[#FF9900] text-gray-700'} font-medium transition-colors duration-200`}
            onClick={() => handleCategoryClick(category.id)}
          >
            {category.name}
          </button>
        ))}
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-md mb-8">
        <h3 className="font-bold mb-4">Filter Products</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-gray-700 mb-2">Price Range</label>
            <select 
              className="w-full p-2 border border-gray-300 rounded-md focus:border-[#FF9900] focus:ring focus:ring-[#FF9900] focus:ring-opacity-50"
              value={filters.priceRange}
              onChange={handlePriceChange}
            >
              {priceRanges.map((range) => (
                <option key={range.value} value={range.value}>{range.label}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-gray-700 mb-2">Customer Rating</label>
            <select 
              className="w-full p-2 border border-gray-300 rounded-md focus:border-[#FF9900] focus:ring focus:ring-[#FF9900] focus:ring-opacity-50"
              value={filters.rating}
              onChange={handleRatingChange}
            >
              {ratingFilters.map((rating) => (
                <option key={rating.value} value={rating.value}>{rating.label}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-gray-700 mb-2">Sort By</label>
            <select 
              className="w-full p-2 border border-gray-300 rounded-md focus:border-[#FF9900] focus:ring focus:ring-[#FF9900] focus:ring-opacity-50"
              value={filters.sortBy}
              onChange={handleSortChange}
            >
              {sortOptions.map((option) => (
                <option key={option.value} value={option.value}>{option.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CategoryFilters;
