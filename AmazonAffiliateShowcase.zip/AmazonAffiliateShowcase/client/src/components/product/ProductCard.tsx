import { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const renderRating = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating - fullStars >= 0.5;
    const stars = [];

    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={`full-${i}`}>★</span>);
    }

    if (hasHalfStar) {
      stars.push(<span key="half">★</span>);
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={`empty-${i}`}>☆</span>);
    }

    return stars;
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300 flex flex-col">
      <img 
        src={product.imageUrl} 
        alt={product.title} 
        className="w-full h-48 object-cover"
      />
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="text-lg font-medium mb-2">{product.title}</h3>
        <p className="text-gray-600 text-sm mb-4 flex-grow">{product.description}</p>
        <div className="flex justify-between items-center mb-3">
          <span className="text-[#FF9900] font-bold">${product.price.toFixed(2)}</span>
          <div className="flex text-[#FF9900] text-sm">
            {renderRating(product.rating)}
            <span className="ml-1 text-gray-500">({product.reviewCount.toLocaleString()})</span>
          </div>
        </div>
        <a 
          href={product.amazonUrl} 
          target="_blank" 
          rel="noopener noreferrer"
          className="bg-[#FF9900] hover:bg-opacity-90 text-white text-center py-2 px-4 rounded-md text-sm font-medium transition duration-200"
        >
          View on Amazon
        </a>
      </div>
    </div>
  );
};

export default ProductCard;
