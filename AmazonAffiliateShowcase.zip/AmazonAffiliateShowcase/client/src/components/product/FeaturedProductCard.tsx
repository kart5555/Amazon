import { Product } from "@shared/schema";

interface FeaturedProductCardProps {
  product: Product;
}

const FeaturedProductCard = ({ product }: FeaturedProductCardProps) => {
  const renderRating = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating - fullStars >= 0.5;
    const stars = [];

    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={`full-${i}`}>★</span>);
    }

    if (hasHalfStar) {
      stars.push(<span key="half">★</span>);
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={`empty-${i}`}>☆</span>);
    }

    return stars;
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300 flex flex-col">
      <div className="relative">
        {product.badge && (
          <div className="absolute top-0 left-0 bg-[#FF9900] text-white px-3 py-1 text-sm font-bold">
            {product.badge}
          </div>
        )}
        <img 
          src={product.imageUrl} 
          alt={product.title} 
          className="w-full h-52 object-cover"
        />
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold">{product.title}</h3>
          <span className="text-[#FF9900] font-bold">${product.price.toFixed(2)}</span>
        </div>
        <p className="text-gray-600 mb-4 flex-grow">{product.description}</p>
        <div className="flex items-center mb-4">
          <div className="flex text-[#FF9900]">
            {renderRating(product.rating)}
          </div>
          <span className="ml-2 text-sm text-gray-500">{product.rating.toFixed(1)} ({product.reviewCount.toLocaleString()} reviews)</span>
        </div>
        <a 
          href={product.amazonUrl} 
          target="_blank" 
          rel="noopener noreferrer" 
          className="bg-[#FF9900] hover:bg-opacity-90 text-white text-center py-3 px-4 rounded-md font-medium transition duration-200"
        >
          View on Amazon
        </a>
      </div>
    </div>
  );
};

export default FeaturedProductCard;
