import { useState } from "react";
import HeroSection from "@/components/hero/HeroSection";
import CategoryFilters from "@/components/filters/CategoryFilters";
import ProductCard from "@/components/product/ProductCard";
import FeaturedProductCard from "@/components/product/FeaturedProductCard";
import NewsletterSignup from "@/components/newsletter/NewsletterSignup";
import { useProducts } from "@/hooks/useProducts";
import { useSearch } from "@/hooks/useSearch";
import { FilterState } from "@/types/types";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

const Home = () => {
  const [filters, setFilters] = useState<FilterState>({
    category: null,
    priceRange: "all",
    rating: "all",
    sortBy: "featured"
  });

  const { searchQuery } = useSearch();
  const { products, featuredProducts, isLoading } = useProducts(filters, searchQuery);
  
  const [visibleProducts, setVisibleProducts] = useState(8);

  const loadMoreProducts = () => {
    setVisibleProducts(prev => prev + 8);
  };

  return (
    <>
      <HeroSection />

      <div className="container mx-auto px-6 py-12">
        {/* Featured Section */}
        <section className="mb-16">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold">Editor's Choice</h2>
            <a href="#" className="text-[#FF9900] hover:underline font-medium">See all</a>
          </div>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(3)].map((_, index) => (
                <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                  <Skeleton className="w-full h-52" />
                  <div className="p-6">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-4" />
                    <Skeleton className="h-4 w-full mb-4" />
                    <Skeleton className="h-6 w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProducts.slice(0, 3).map(product => (
                <FeaturedProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </section>

        {/* Category Filters */}
        <CategoryFilters
          filters={filters}
          onFilterChange={setFilters}
        />

        {/* Product Grid */}
        <section id="trending" className="mb-16">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">
            {searchQuery ? `Search Results for "${searchQuery}"` : "Trending Products"}
          </h2>
          
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, index) => (
                <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
                  <Skeleton className="w-full h-48" />
                  <div className="p-4">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-4" />
                    <Skeleton className="h-4 w-2/3" />
                    <Skeleton className="h-10 w-full mt-4" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {products.slice(0, visibleProducts).map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
              
              {products.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-500 text-lg">No products found matching your criteria.</p>
                </div>
              )}
              
              {visibleProducts < products.length && (
                <div className="mt-10 flex justify-center">
                  <Button 
                    onClick={loadMoreProducts}
                    className="bg-white border border-[#232F3E] text-[#232F3E] hover:bg-[#232F3E] hover:text-white font-medium py-3 px-8 rounded-md transition duration-200"
                  >
                    Load More Products
                  </Button>
                </div>
              )}
            </>
          )}
        </section>

        {/* Newsletter Signup */}
        <NewsletterSignup />
      </div>
    </>
  );
};

export default Home;
